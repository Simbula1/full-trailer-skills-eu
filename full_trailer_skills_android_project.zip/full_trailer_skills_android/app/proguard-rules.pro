# No custom shrinking rules needed for this WebView game.
