# Full Trailer Skills EU — Android

Offline Android wrapper for the full-trailer manoeuvring game.

## Mobile changes
- Landscape orientation
- Immersive fullscreen
- Large touch controls
- Safe-area handling for notches/navigation gestures
- Screen stays awake while playing
- Game runs fully offline from `app/src/main/assets/index.html`

## Build
Requires JDK 17, Android SDK 35 and Gradle 8.9.

```bash
gradle assembleDebug
```

APK: `app/build/outputs/apk/debug/app-debug.apk`

The included GitHub Actions workflow can build the installable APK automatically.


GitHub Actions builds an installable debug APK on pushes to main and pull requests targeting main.
